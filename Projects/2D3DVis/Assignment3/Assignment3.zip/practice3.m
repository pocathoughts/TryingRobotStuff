function [improved_image] = enhanceWithNIR(vis_image, nir_image)
%reading in the vis image
vis_img = imread(vis_image);

%reading in the nir image
nir_img = imread(nir_image);

%resize the images to be square 
vis_img = imresize(img, [500 500]);
nir_img = imresize(img, [500 500]);

%get vChannel of the images
hsv_vis = makeHSV(vis_img);
hsv_nir = makeHSV(nir_img);
v_VIS = hsv_vis(:,:,3);
v_NIR = hsv_nir(:,:,3);

%get the decomposition for the VIS image
[cAVIS, cHVIS, cVVIS, cDVIS] = getHaarCoeffs(v_VIS)

%get the decomposition for the NIR image
[cANIR, cHNIR, cVNIR, cDNIR] = getHaarCoeffs(v_NIR)

%combine the coefficients
cA = (cAVIS + cANIR)/2;
cH = (cHVIS + cHNIR)/2;
cV = (cVVIS + cVNIR)/2;
cD = (cDVIS + cDVIS)/2;

%inverse transform the coefficients to get our resulting image
X = idwt2(cA,cH,cV,cD,'haar') 


figure, imshow(X), title('final');
hsv = makeHSV(img);
v = hsv(:,:,3);

