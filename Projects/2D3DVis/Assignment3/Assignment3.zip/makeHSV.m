function hsvImg = makeHSV(img)

hsvImg = rgb2hsv(img) 

end