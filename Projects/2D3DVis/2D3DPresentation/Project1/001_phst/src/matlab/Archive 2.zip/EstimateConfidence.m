function confidence = EstimateConfidence(confidences, pColor)
    % computeing errors is the estimateions?
    %compute error with noise
    fitting lsq to errors
    %confidence is size of pColo(num of pixels)
    noisyPColor = imnoise(pColor,'salt & pepper');
    %error we computed in update errors with confidences to update lsq data
    %a value (look at file) computing errors we have a set of errors
    %tracking each channel is off form ideal
    
    %how do we calculate confidencee %do separatley for each channel 
    %normalize normals
    
    %every value is 0 -1 
    
    for num of pixels 
        
            add weight to that and give it a confidence
            max intensity at i for this p color
            confidence  = max /by noise make sure noise is always the inimum value
            confidence[i]  1-max/greaternoise);/2 * noise
            
            %%confidence i = squrt(rmax(rgb at i) for p color) < = 1
            confidence = squre(1 - (mas(rgb)/wxnosie) <= 1.0
    confidence at i = 
            end
            
    error deviation between dot product and confidence
    
    %%%Make update error, print imwrite predicted imwrite color
    imwrite(diff)