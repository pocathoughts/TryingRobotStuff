% Implement Solver
function [bTerminate, normals, lsqData, pColor] = SolveNormals (lsqData, normals, pColor)
    %lsqData - lsq stuff
    %normals - normal values
    %pColor - pColor
    %lsq data with rgb values  %other lsq are r g b chennel
    
    %we get a normal vector 
    %     function [N,R, fail] = PixelNormal(I, L)
% 
%    fail = 0;
%    how to calculate certain things
%    I  = I'; %inverse of intensites
%    LT = L';  %inverse of light poisitons (LT light transpose)
%    A  = LT*L; 
%    b  = LT*I;
%    g  = inv(A)*b; %holds albedo and normal vectos we are solving for
%    R  = norm(g);
%    N  = g/R; % N is rormals

    
    %%EIGEN Vector VALUE GOES HERE
    eigenvec %eigen value sorted smalllest to largest
    %this is wehre you do the eigne vecotrwith lsq data and color
    compute normals
    
    
    %if we already have normal values, what are we solving for? Not
    %entirely sure what to do here

end