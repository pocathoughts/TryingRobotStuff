function Normals = PixelNormal(LightIntens, LightPos) %(I, L)

num_Intensities = length(LightIntens);
num_Positions = length(LightPos);

if(num_Intensities ~= num_Positions)
    disp('something went wrong');
    return;
end


transpIntensities  = LightIntens';
transpLightPos = LightPos'; 
one  = transpLightPos*LightPos;
two  = transpLightPos*transpIntensities;
bigMatrix  = inv(one)*two; %holds albedo and normal vectos we are solving for
Albedo  = norm(bigMatrix); albedo
Normals  = bigMatrix/Albedo; % N is rormals


end 