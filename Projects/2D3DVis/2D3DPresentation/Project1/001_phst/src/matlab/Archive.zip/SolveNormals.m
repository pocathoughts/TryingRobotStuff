% Implement Solver
function [bTerminate, normals, lsqData, pColor] = SolveNormals (lsqData, normals, pColor)
    %lsqData - lsq stuff
    %normals - normal values
    %pColor - pColor
    %lsq data with rgb values  %other lsq are r g b chennel
    
    %we get a normal vector 
    
    
    %%EIGEN Vector VALUE GOES HERE
    eigenvec %eigen value sorted smalllest to largest
    %this is wehre you do the eigne vecotrwith lsq data and color
    compute normals
    
    
    %if we already have normal values, what are we solving for? Not
    %entirely sure what to do here

end