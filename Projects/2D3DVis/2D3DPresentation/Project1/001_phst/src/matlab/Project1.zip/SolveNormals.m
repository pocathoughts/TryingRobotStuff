% Implement Solver
function [bTerminate, normals, lsqData, pColor] = SolveNormals (lsqData, normals, pColor)
    %lsqData - lsq stuff
    %normals - normal values
    %pColor - pColor
    
    %if we already have normal values, what are we solving for? Not
    %entirely sure what to do here

end